﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class onTrigger : MonoBehaviour {
	/*
	void onTriggerEnter(Collider Other)
	{
		if (Other.gameObject.tag == "enemy" && Other.osTrigger == false) {
			status = "Damaged";
			onDamage();
		}
	}
	*/
	/*
	void AnimationUpdate()
	{
		if(status=="Damaged"){
			Animator.SetTrigger("onDamage")
			return;
	}
			
		Animator.setBool("iswalking",false);
   */ 
	/*
		void onDamage()
		{
			Vector3 knockbackDegree = new Vector(30f,1f,1f);
			rigidbody.AddForce(knockbackDegree*350f,ForceMode.Impulse);
		}
	*/


}
