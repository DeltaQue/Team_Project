﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveKey : MonoBehaviour {

    public int speed;
    Rigidbody rigidbody;
    Vector3 movement;
    
    void Awake () {
        rigidbody = GetComponent<Rigidbody>();
	}
    
    public void Update()
    {
        moveObject();
    }

    public void moveObject()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");

        movement.Set(h, 0, v);
        movement = movement.normalized*speed*Time.deltaTime;

        rigidbody.MovePosition(transform.position + movement);
        
    }
}


