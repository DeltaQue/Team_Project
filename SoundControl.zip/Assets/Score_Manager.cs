﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/*
public class Score_Manager : MonoBehaviour {

	void Awake()
	{
		Score = 0;
	}
		
	}
}
*/
